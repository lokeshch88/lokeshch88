import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import ProductCard from "./ProductCard";
import "../CssFiles/Home.css"; // Optional for custom styles

const Home = () => {
  const [cart, setCart] = useState([]);
  const navigate = useNavigate();
  
  const products = [
    { id: 1, name: "Product 1", price: 29.99, image: "https://via.placeholder.com/150" },
    { id: 2, name: "Product 2", price: 49.99, image: "https://via.placeholder.com/150" },
    { id: 3, name: "Product 3", price: 19.99, image: "https://via.placeholder.com/150" },
    { id: 4, name: "Product 4", price: 99.99, image: "https://via.placeholder.com/150" },
  ];

  useEffect(() => {
    const user = localStorage.getItem("username");
    if (user) {
      const savedCart = JSON.parse(localStorage.getItem("cart")) || {};
      setCart(savedCart[user] || []);
    }
  }, []);

  const addToCart = (product) => {
    const user = localStorage.getItem("username");
    if (!user) {
      alert("Please log in first to add items to the cart.");
      return;
    }

    const updatedCart = JSON.parse(localStorage.getItem("cart")) || {};
    if (!updatedCart[user]) {
      updatedCart[user] = [];
    }

    const existingProduct = updatedCart[user].find(item => item.id === product.id);
    if (existingProduct) {
      existingProduct.quantity += 1;
    } else {
      updatedCart[user].push({ ...product, quantity: 1 });
    }

    localStorage.setItem("cart", JSON.stringify(updatedCart));
    setCart(updatedCart[user]);
    alert(`${product.name} added to cart!`);
  };

  const handleLogout = () => {
    localStorage.removeItem("username");
    alert("All cart items will be removed");
    localStorage.removeItem("cart");
    setCart([]);
    navigate("/");
  };

  const handleLogin = () => {
    navigate("/");
  };

  const handleGoToCart = () => {
    navigate("/cart");
  };

  const updateQuantity = (id, amount) => {
    const user = localStorage.getItem("username");
    const updatedCart = JSON.parse(localStorage.getItem("cart")) || {};
    if (!updatedCart[user]) return;

    const existingProduct = updatedCart[user].find(item => item.id === id);
    if (existingProduct) {
      const newQuantity = existingProduct.quantity + amount;
      if (newQuantity <= 0) {
        updatedCart[user] = updatedCart[user].filter(item => item.id !== id);
      } else {
        existingProduct.quantity = newQuantity;
      }
      localStorage.setItem("cart", JSON.stringify(updatedCart));
      setCart(updatedCart[user]);
    }
  };

  return (
    <div className="home">
      <h1>Welcome</h1>
      <div>
        <button onClick={handleGoToCart}>Go To Cart</button>
        {localStorage.getItem("username") ? (
          <button onClick={handleLogout}>Logout</button>
        ) : (
          <button onClick={handleLogin}>Login</button>
        )}
      </div>
      <div className="product-list">
        {products.map(product => (
          <ProductCard
            key={product.id}
            product={{
              ...product,
              quantity: cart.find(item => item.id === product.id)?.quantity || 0,
            }}
            addToCart={addToCart}
            updateQuantity={updateQuantity}
          />
        ))}
      </div>
    </div>
  );
};

export default Home;
