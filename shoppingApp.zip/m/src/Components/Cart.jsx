import React, { useState, useEffect } from "react";
import ProductCard from "./ProductCard"; // Import the ProductCard component
import "../CssFiles/Cart.css"; // Add custom styles if needed

const Cart = () => {
  const [cartItems, setCartItems] = useState([]);
  const [username, setUsername] = useState("");

  useEffect(() => {
    // Get the username from localStorage
    const storedUsername = localStorage.getItem("username");
    setUsername(storedUsername);

    // Retrieve cart items for the logged-in user
    const savedCart = localStorage.getItem("cart");
    const parsedCart = savedCart ? JSON.parse(savedCart) : {}; // Parse if exists

    // Initialize cart items as an array
    if (storedUsername && parsedCart[storedUsername]) {
      setCartItems(parsedCart[storedUsername]);
    } else {
      setCartItems([]); // Ensure it's an empty array if no items
    }
  }, []);

  const handleProceedToBuy = () => {
    alert("Proceeding to buy items...");
    // Add your buy logic here
  };

  return (
    <div className="cart">
      <h2>Your Cart</h2>
      {cartItems.length === 0 ? (
        <p>No items in cart.</p>
      ) : (
        <div className="cart-items">
          {cartItems.map((item, index) => (
            <ProductCard
              key={index}
              product={{ ...item }} // Pass product data to the ProductCard
            />
          ))}
        </div>
      )}
      {cartItems.length > 0 && (
        <button onClick={handleProceedToBuy}>Proceed to Buy</button>
      )}
    </div>
  );
};

export default Cart;
