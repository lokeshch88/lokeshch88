import MakerForm from './MakerForm'
const MakerDashboard =()=>{
return(
    <div>
       
        <MakerForm/>
    </div>
)
}
export default MakerDashboard;
