import { useEffect, useState } from "react";
import "../css/makerFormData.css";

const UpdateModal = ({
  onClose,
  companyId,
  accountNo,
  activeFlag,
  status,
  id,
}) => {
  console.log(companyId, status, id);
  const [formData, setFormData] = useState({
    serviceCdId: "",
    accountNo: accountNo,
    activeFlag: activeFlag,
  });

  const [originalServices, setOriginalServices] = useState([]);

  const [operationMode, setOperationMode] = useState("O");
  const [accounts, setAccounts] = useState([]);
  const [approvers, setApprovers] = useState([]);
  const [selectedApprovers, setSelectedApprovers] = useState({});
  const [selectedGroups, setSelectedGroups] = useState({});
  const [initialSelectedGroups, setInitialSelectedGroups] = useState({});
  const [userDetails, setUserDetails] = useState(null);
  const [sowName, setSowName] = useState(null);
  const [addedServices, setAddedServices] = useState([]);
  const [makerDetails, setMakerDetails] = useState({
    makerCd: "",
    makerDt: "",
  });
  const [authorDetails, setAuthorDetails] = useState({
    authorCd: "",
    authorDt: "",
  });
  const groups = [
    {
      groupId: "2",
      groupName: "Financial Transactions - Bulk Transaction and Group",
      groupDesc: "Multiple Payments...",
    },
    {
      groupId: "3",
      groupName: "Financial Transactions - Onscreen",
      groupDesc: "Own Account Transfer...",
    },
    {
      groupId: "5",
      groupName: "Salary Management",
      groupDesc: "Upload Salary...",
    },
    {
      groupId: "7",
      groupName: "Financial Transactions - Tax",
      groupDesc: "GST Transaction Only",
    },
  ];

  const [selectedAccountNo, setSelectedAccountNo] = useState(accountNo);
  const [groupServiceName, setGroupServiceName] = useState([]);

  useEffect(() => {
    setGroupServiceName();
  }, []);

  useEffect(() => {
    const fetchDetails = async () => {
      if (companyId && accountNo) {
        const user = {
          custid: companyId,
          accNo: accountNo,
          status: status,
          mode: "Update",
        };
        console.log("data sent to get details from update ", user);

        try {
          const response = await fetch("http://192.168.0.108:8081/users/view", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(user),
          });

          if (!response.ok)
            throw new Error(`HTTP error! status: ${response.status}`);
          const data = await response.json();

          setUserDetails(data);

          console.log("data fetched by view for update ", data);
          setFormData({
            serviceCdId: data.serviceCdId || "",
            accountNo: data.accountNo || accountNo,
            activeFlag: data.activeFlag || "Y",
          });

          const selectedGroupIds = {};
          data.forEach((userDetail) => {
            const groupId = userDetail.serviceCd;
            if (groupId) {
              selectedGroupIds[groupId] = {
                name: userDetail.groupName,
                dailyLimit: userDetail.dailyLimit,
              };
            }
          });
          setSelectedGroups(selectedGroupIds);
          setInitialSelectedGroups(selectedGroupIds); // Store initial values

          const allSelectedApprovers = {};
          data.forEach((userDetail) => {
            if (userDetail.approverList) {
              const parsedApprovers = parseApproverList(
                userDetail.approverList
              );
              Object.assign(allSelectedApprovers, parsedApprovers);
            }
          });
          setSelectedApprovers(allSelectedApprovers);

          const selectedUserDetails = data.filter(
            (userDetail) => userDetail.accountNo === selectedAccountNo
          );

          // Assuming you want the last user details for maker and author
          const lastUser = selectedUserDetails[selectedUserDetails.length - 1];
          setMakerDetails({
            makerCd: lastUser.makerCd,
            makerDt: lastUser.makerDt,
          });
          setAuthorDetails({
            authorCd: lastUser.authorCd,
            authorDt: lastUser.authorDt,
          });
        } catch (error) {
          console.error("Error fetching user details:", error);
        }
      }
    };

    fetchDetails();
  }, [companyId, accountNo]);

  const parseApproverList = (approverList) => {
    const approvers = {};
    const entries = approverList.split("|").filter(Boolean);
    entries.forEach((entry) => {
      const [id, limit] = entry.split("#");
      approvers[id] = { perTransactionLimit: limit };
    });
    return approvers;
  };

  useEffect(() => {
    const fetchAccountsAndApprovers = async () => {
      if (companyId) {
        try {
          const accountsResponse = await fetch(
            `http://192.168.0.108:8081/users/account-list/${companyId}`
          );
          if (!accountsResponse.ok)
            throw new Error(`HTTP error! status: ${accountsResponse.status}`);
          const accountData = await accountsResponse.json();
          setAccounts(accountData);

          const approversResponse = await fetch(
            `http://192.168.0.108:8081/users/approver-list/${companyId}`
          );
          if (!approversResponse.ok)
            throw new Error(`HTTP error! status: ${approversResponse.status}`);
          const approverData = await approversResponse.json();
          const approversArray = Object.entries(approverData).map(
            ([id, name]) => ({
              approverId: id,
              approverName: name,
              dailyLimit: "",
            })
          );
          setApprovers(approversArray);
        } catch (err) {
          console.log("Error fetching accounts or approvers", err);
        }
      }
    };

    fetchAccountsAndApprovers();
  }, [companyId]);

  const handleRadioChange = (e) => {
    setOperationMode(e.target.value); // Update operation mode based on radio selection
  };

  const handleUpdate = async () => {
    // Ensure there's data to update
    if (addedServices.length === 0) {
      alert("No services in list to update. Please add to list.");
      return;
    }

    console.log("Updated data to be sent:", addedServices);

    try {
      const response = await fetch("http://192.168.0.108:8081/users/update", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(addedServices), // Use addedServices directly
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      alert("Data updated successfully");
      console.log("Data submitted successfully:", addedServices);
    } catch (error) {
      console.error("Error submitting data:", error);
    }
  };

  const handleAddToList = () => {
    // Validation: Check if a service is selected
    if (!companyId) {
      alert("Please select a service before adding to the list.");
      return;
    }

    // Check if at least one group is selected
    if (Object.keys(selectedGroups).length === 0) {
      alert("Please select at least one group.");
      return;
    }

    // Validate approvers and limits
    const approverList = Object.entries(selectedApprovers)
      .filter(([_, limit]) => limit.perTransactionLimit)
      .map(([id, limit]) => `${id}#${limit.perTransactionLimit}`);

    if (approverList.length === 0) {
      alert("Please select at least one approver before adding to the list.");
      return;
    }

    // Validate daily limits and approver limits
    for (const [groupId, groupData] of Object.entries(selectedGroups)) {
      const dailyLimit = groupData.dailyLimit;

      // Check if dailyLimit is a valid number
      if (isNaN(dailyLimit) || dailyLimit === null || dailyLimit <= 0) {
        alert(`Daily limit for group ${groupId} must be a valid number.`);
        return;
      }

      // Validate that all approver limits are greater than or equal to the daily limit
      const isValidLimits = approverList.every((approver) => {
        const [approverId, limit] = approver.split("#");
        console.log(
          "check for valid transaction limit ",
          approverId,
          limit,
          " with daily limit ",
          dailyLimit
        );
        return !isNaN(limit) && dailyLimit >= parseFloat(limit);
      });

      if (!isValidLimits) {
        alert(
          `All selected group limits must be greater than or equal to the per transaction limit for group ${groupId}.`
        );
        return;
      }
    }

    // Iterate through selected groups and create separate entries
    const newServices = Object.entries(selectedGroups).map(
      ([groupId, groupData]) => ({
        accountNo: formData.accountNo,
        activeFlag: formData.activeFlag,
        serviceCdId: companyId,
        serviceCd: groupId,
        approverList: approverList.join("|"),
        dailyLimit: groupData.dailyLimit,
        operationMode,
        authStatus: status,
        id: groupData.id,
      })
    );

    // Check for older value against existing entries
    console.log("data fetched to validate ", userDetails);
    for (const newService of newServices) {
      const existingService = userDetails.find(
        (service) =>
          service.accountNo === newService.accountNo &&
          service.serviceCd === newService.serviceCd
      );

      if (
        existingService &&
        existingService.dailyLimit === newService.dailyLimit
      ) {
        setAddedServices([]);
        alert(
          `Older value found for services: . Please change the daily limit.`
        );
        return;
      }
    }

    // Check for duplicates
    const duplicates = newServices.some((newService) =>
      addedServices.some(
        (service) =>
          service.serviceCdId === newService.serviceCdId &&
          service.serviceCd === newService.serviceCd
      )
    );

    if (duplicates) {
      alert(
        "One or more of these services with the selected groups has already been added."
      );
      return;
    }

    // Add the new services to the list
    setAddedServices((prev) => [...prev, ...newServices]);
    console.log("Added to list:", newServices);
    console.log("final list to be sent ", addedServices);
    console.log("selected service with their ids ", selectedGroups);
    // Reset selections
    setSelectedGroups({});
    setSelectedApprovers({});
  };

  //copy limit button handler
  const handleCopyLimit = () => {
    // Find the limit of the first selected approver
    const selectedApproverIds = Object.keys(selectedApprovers);
    if (selectedApproverIds.length === 0) {
      alert("Please select at least one approver to copy the limit.");
      return;
    }

    // Get the first selected approver's ID
    const firstApproverId = selectedApproverIds[0];
    const limitToCopy = selectedApprovers[firstApproverId];

    // Update all selected approvers with the copied limit
    const updatedApprovers = {};
    for (const approverId of selectedApproverIds) {
      updatedApprovers[approverId] = limitToCopy;
    }
    setSelectedApprovers(updatedApprovers);
  };

  const [disabledGroups, setDisabledGroups] = useState({});
  const [isOnlyNewServiceDisabled, setIsOnlyNewServiceDisabled] =
    useState(false);

  const handleOnlyNewService = () => {
    // Iterate through the selected groups and disable them
    const newDisabledGroups = {};
    for (const groupId of Object.keys(selectedGroups)) {
      newDisabledGroups[groupId] = true; // Disable this group
    }
    setDisabledGroups(newDisabledGroups);

    // Optionally, clear the selected groups if you want to reset them
    setSelectedGroups({});
    setIsOnlyNewServiceDisabled(true);
  };

  return (
    <div className="modal">
      <div className="modal-content">
        <span className="close" onClick={onClose}>
          &times;
        </span>
        <h2 style={{ backgroundColor: "rgb(104, 104, 202)", color: "white" }}>
          Update
        </h2>
        <form className="modal-form">
          <div className="companyid-group">
            <div>
              <label>Company ID</label>
              <input
                name="serviceCdId"
                type="text"
                value={companyId}
                disabled
              />
            </div>
            <div>
              <label>Active Flag</label>
              <input
                name="activeFlag"
                type="text"
                value={formData.activeFlag}
                onChange={(e) =>
                  setFormData({ ...formData, activeFlag: e.target.value })
                }
                disabled
              />
            </div>
            <br />
            <div>{sowName}</div>
          </div>
          <div className="accountsno-group">
            <label>Account Number</label>
            <select
              name="accountNo"
              value={formData.accountNo}
              onChange={(e) =>
                setFormData({ ...formData, accountNo: e.target.value })
              }
            >
              <option value="">Select Account</option>
              {accounts.map((account, index) => (
                <option
                  key={`${account.trim()}-${index}`}
                  value={account.trim()}
                >
                  {account.trim()}
                </option>
              ))}
            </select>
          </div>
          <div className="limit-details">
            <div className="tables">
              <div className="group-table">
                <table>
                  <thead>
                    <tr>
                      <th></th>
                      <th>Group Service Name</th>
                      <th>Daily Limit (In Rs.)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {groups.map((group) => {
                      const isDisabled = addedServices.some(
                        (addedService) =>
                          addedService.serviceCd === group.groupId
                      );

                      return (
                        <tr key={group.groupId}>
                          <td>
                            <input
                              type="checkbox"
                              checked={
                                selectedGroups[group.groupId] !== undefined
                              }
                              onChange={(e) => {
                                if (e.target.checked) {
                                  const userDetail = userDetails.find(
                                    (el) => el.serviceCd === group.groupId
                                  );

                                  if (!userDetail) {
                                    alert(
                                      "Can't add this record: User detail not found."
                                    );
                                    e.target.checked = false; // Uncheck the checkbox
                                    return; // Exit the function
                                  }

                                  setSelectedGroups((prev) => ({
                                    ...prev,
                                    [group.groupId]: {
                                      name: group.groupName,
                                      dailyLimit: "",
                                      recordid: userDetail.id, // Use the found user's ID
                                    },
                                  }));
                                } else {
                                  setSelectedGroups((prev) => {
                                    const newSelectedGroups = { ...prev };
                                    delete newSelectedGroups[group.groupId];
                                    return newSelectedGroups;
                                  });
                                }
                              }}
                              disabled={isDisabled}
                            />
                          </td>
                          <td>
                            <b>{group.groupName}</b>
                            <br />
                            {group.groupDesc}
                          </td>
                          <td>
                            <input
                              type="text"
                              value={
                                selectedGroups[group.groupId]?.dailyLimit || ""
                              }
                              onChange={(e) => {
                                const userDetail = userDetails.find(
                                  (el) => el.serviceCd === group.groupId
                                );

                                if (!userDetail) {
                                  alert(
                                    "Can't update daily limit: User detail not found."
                                  );
                                  return; // Exit the function
                                }

                                setSelectedGroups((prev) => ({
                                  ...prev,
                                  [group.groupId]: {
                                    ...prev[group.groupId],
                                    dailyLimit: e.target.value,
                                    id: userDetail.id, // Use the found user's ID
                                  },
                                }));
                              }}
                            />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              <div className="approvers-table">
                <table>
                  <thead>
                    <tr>
                      <th></th>
                      <th>Approver ID</th>
                      <th>Approver Name</th>
                      <th>Per Transaction Limit (In Rs.)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {approvers.length > 0 ? (
                      approvers.map((approver) => {
                        const isDisabled = approver.approverId === companyId;

                        return (
                          <tr key={approver.approverId}>
                            <td>
                              <input
                                type="checkbox"
                                checked={
                                  selectedApprovers[approver.approverId] !==
                                  undefined
                                }
                                onChange={(e) => {
                                  if (e.target.checked) {
                                    setSelectedApprovers((prev) => ({
                                      ...prev,
                                      [approver.approverId]: {
                                        perTransactionLimit: "",
                                      },
                                    }));
                                  } else {
                                    setSelectedApprovers((prev) => {
                                      const newSelected = { ...prev };
                                      delete newSelected[approver.approverId];
                                      return newSelected;
                                    });
                                  }
                                }}
                                disabled={isDisabled}
                              />
                            </td>
                            <td>{approver.approverId}</td>
                            <td>{approver.approverName}</td>
                            <td>
                              <input
                                type="text"
                                value={
                                  selectedApprovers[approver.approverId]
                                    ?.perTransactionLimit || ""
                                }
                                onChange={(e) => {
                                  setSelectedApprovers((prev) => ({
                                    ...prev,
                                    [approver.approverId]: {
                                      perTransactionLimit: e.target.value,
                                    },
                                  }));
                                }}
                                disabled={isDisabled}
                              />
                            </td>
                          </tr>
                        );
                      })
                    ) : (
                      <tr>
                        <td colSpan="4">No Approvers Available</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
            <div className="btm-limit-group">
              <div className="operation-group">
                <label>Select Operation Mode: </label>
                <label>
                  <input
                    type="radio"
                    value="O"
                    checked={operationMode === "O"}
                    onChange={handleRadioChange}
                  />
                  Any one of the above
                </label>
                <label>
                  <input
                    type="radio"
                    value="J"
                    checked={operationMode === "J"}
                    onChange={handleRadioChange}
                  />
                  All of the above
                </label>
              </div>
              <div className="btm-button-group">
                <button type="button" onClick={handleAddToList}>
                  Add to list
                </button>
                <button type="button" onClick={handleCopyLimit}>
                  Copy transaction limit
                </button>
                <button type="button">Only new service</button>
              </div>
            </div>
          </div>

          {makerDetails.makerCd && (
            <div className="maker-author-group">
              <div>Maker: [{makerDetails.makerCd}]</div>
              <div>
                Maker Date: [
                {makerDetails.makerDt
                  ? new Date(makerDetails.makerDt).toLocaleDateString()
                  : ""}
                ]
              </div>

              {authorDetails.authorCd && (
                <div>Author: [{authorDetails.authorCd}]</div>
              )}
              {authorDetails.authorCd && (
                <div>
                  Author Date: [
                  {authorDetails.authorDt
                    ? new Date(authorDetails.authorDt).toLocaleDateString()
                    : ""}
                  ]
                </div>
              )}
            </div>
          )}
          <div className="instructions">
            Note: 1. By selecting group service name user can 'View' or 'Update'
            limit setup of multiple group services in the 'Update' & 'View' tab
          </div>
          <div className="button-group">
            <button type="button" onClick={handleUpdate}>
              Update
            </button>
            <button type="button" onClick={onClose}>
              Close
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default UpdateModal;
