import React from 'react';
import { useNavigate } from 'react-router-dom';
import '../css/home.css'; // Adjust the path as necessary

const Home = () => {
  const navigate = useNavigate();

  const handleSingleGoMaker = () => {
    navigate('/maker-dashboard'); 
  };

  const handleSingleGoAuthor = () => {
    navigate('/author-dashboard'); 
  };

  const handleLogout = () => {
    localStorage.removeItem("username");
    navigate('/'); 
  };

  return (
    <div className="home-container">
      <button className="home-button" onClick={handleSingleGoMaker}>SingleGo Maker</button>
      <button className="home-button" onClick={handleSingleGoAuthor}>SingleGo Author</button>
      <button className="home-button" onClick={handleLogout}>Logout</button>
    </div>
  );
};

export default Home;
