import { useEffect, useState } from "react";
import "../css/makerFormData.css";

const ViewUserModal = ({
  onClose,
  companyId,
  accountNo,
  activeFlag,
  status,
  serviceCd,
}) => {
  console.log("selected record status ", status);
  const [selectedAccountNo, setSelectedAccountNo] = useState(accountNo);
  const [formData, setFormData] = useState({
    serviceCdId: "",
    accountNo: accountNo,
    activeFlag: activeFlag,
  });
  const [operationMode, setOperationMode] = useState("O");
  const [accounts, setAccounts] = useState([]);
  const [approvers, setApprovers] = useState([]);
  const [selectedApprovers, setSelectedApprovers] = useState({});
  const [selectedGroups, setSelectedGroups] = useState({});
  const [userDetails, setUserDetails] = useState(null);
  const [sowName, setSowName] = useState(null);
  const [makerDetails, setMakerDetails] = useState({
    makerCd: "",
    makerDt: "",
  });
  const [authorDetails, setAuthorDetails] = useState({
    authorCd: "",
    authorDt: "",
  });
  const [selectedService, setSelectedService] = useState(null);
  const [serviceApprovers, setServiceApprovers] = useState({});
  const groups = [
    {
      groupId: "2",
      groupName: "Financial Transactions - Bulk Transaction and Group",
      groupDesc:
        "Multiple Payments To A Single Beneficiary,Transfer Funds To Registered Group,Bulk Transaction Upload",
    },
    {
      groupId: "3",
      groupName: "Financial Transactions - Onscreen",
      groupDesc:
        "Own Account Transfer,Open FD,Remitter Payment,Create New SI,Financial Transactions,Transfer Funds To Registered Beneficiary,Ad-hoc Payment",
    },
    {
      groupId: "5",
      groupName: "Salary Management",
      groupDesc:
        "Upload Salary,Group Salary Payment,Salary Payment to Employee",
    },
    {
      groupId: "7",
      groupName: "Financial Transactions - Tax",
      groupDesc: "GST Transaction Only",
    },
  ];

  const parseApproverList = (approverList) => {
    const approvers = {};
    const entries = approverList.split("|").filter(Boolean);
    entries.forEach((entry) => {
      const [id, limit] = entry.split("#");
      approvers[id] = { perTransactionLimit: limit };
    });
    return approvers;
  };

  useEffect(() => {
    const fetchDetails = async () => {
      if (companyId && selectedAccountNo) {
        const user = {
          custid: companyId,
          accNo: selectedAccountNo,
          status: status,
          mode: "View",
        };
        console.log("data sent to fetch view method ", user);
        try {
          const response = await fetch("http://192.168.0.108:8081/users/view", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify(user),
          });

          if (!response.ok)
            throw new Error(`HTTP error! status: ${response.status}`);
          const data = await response.json();
          console.log("data received ", data);
          setUserDetails(data);

          const selectedUserDetails = data.filter(
            (userDetail) => userDetail.accountNo === selectedAccountNo
          );

          const selectedGroupIds = {};
          const approversData = {};
          selectedUserDetails.forEach((selectedUser) => {
            if (selectedUser.approverList) {
              const parsedApprovers = parseApproverList(
                selectedUser.approverList
              );
              Object.assign(approversData, parsedApprovers);
            }

            // Map all group services based on selectedUser's serviceCd
            groups.forEach((group) => {
              if (selectedUser.serviceCd === group.groupId) {
                selectedGroupIds[group.groupId] = {
                  name: group.groupName,
                  dailyLimit: selectedUser.dailyLimit,
                  activeFlag: selectedUser.activeFlag,
                  authStatus: selectedUser.authStatus,
                };
              }
            });
          });

          setSelectedGroups(selectedGroupIds);
          setSelectedApprovers(approversData);

          // Assuming last user details for maker and author
          const lastUser = selectedUserDetails[selectedUserDetails.length - 1];
          setMakerDetails({
            makerCd: lastUser.makerCd,
            makerDt: lastUser.makerDt,
          });
          setAuthorDetails({
            authorCd: lastUser.authorCd,
            authorDt: lastUser.authorDt,
          });

          const selectedUserDetailsForOpertaionMode = data.filter(
            (userDetail) => userDetail.accountNo === selectedAccountNo
          );

          // Update operationMode based on serviceCd
          const matchedUser = selectedUserDetailsForOpertaionMode.find(
            (userDetail) => userDetail.serviceCd === serviceCd
          );
          if (matchedUser) {
            setOperationMode(matchedUser.operationMode || "O"); // Default to "O" if not set
          }
        } catch (error) {
          console.error("Error fetching user details:", error);
        }
      }
    };

    fetchDetails();
  }, [companyId, selectedAccountNo]);

  useEffect(() => {
    const fetchAccountsAndApprovers = async () => {
      if (companyId) {
        try {
          const accountsResponse = await fetch(
            `http://192.168.0.108:8081/users/account-list/${companyId}`
          );
          const approversResponse = await fetch(
            `http://192.168.0.108:8081/users/approver-list/${companyId}`
          );

          if (!accountsResponse.ok || !approversResponse.ok) {
            throw new Error(`HTTP error!`);
          }

          const accountData = await accountsResponse.json();
          setAccounts(accountData);

          const approverData = await approversResponse.json();
          const approversArray = Object.entries(approverData).map(
            ([id, name]) => ({
              approverId: id,
              approverName: name,
              dailyLimit: "",
            })
          );
          setApprovers(approversArray);
        } catch (err) {
          console.log("Error fetching accounts or approvers", err);
        }
      }
    };

    fetchAccountsAndApprovers();
  }, [companyId]);

  useEffect(() => {
    const fetchsowname = async () => {
      if (companyId) {
        try {
          const sowResponse = await fetch(
            `http://192.168.0.108:8081/users/sow-name/${companyId}`
          );
          if (!sowResponse.ok) {
            throw new Error(`Http errror! while fetching sow`);
          }
          const sow = await sowResponse.text();
          console.log("sow name fetched ", sow);
          setSowName(sow);
        } catch (err) {
          console.log(
            "error fetching sow name by company id in view componenet ",
            err
          );
        }
      }
    };

    fetchsowname();
  }, [companyId]);

  // const handleServiceClick = (groupId) => {
  //   setSelectedService(groupId);
  //   // Create a new object that maps approvers to the selected service
  //   const approversForService = {};
  //   for (const approverId in selectedApprovers) {
  //     // Assume you have a way to determine if the approver belongs to the selected service
  //     // Replace this condition with your actual logic
  //     if (selectedApprovers[approverId].serviceCd === groupId) {
  //       approversForService[approverId] = selectedApprovers[approverId];
  //     }
  //   }
  //   setServiceApprovers(approversForService);
  // };
  const handleAccountChange = (e) => {
    setSelectedAccountNo(e.target.value);
  };

  const numberToWords = (num) => {
    const ones = [
      '', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
      'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen',
      'Seventeen', 'Eighteen', 'Nineteen'
    ];
  
    const tens = [
      '', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'
    ];
  
    const aboveHundred = [
      '', 'Hundred', 'Thousand', 'Lakh', 'Crore'
    ];
  
    if (num === 0) return 'Zero';
  
    let words = '';
    let crore = Math.floor(num / 10000000);
    let lakh = Math.floor((num % 10000000) / 100000);
    let thousand = Math.floor((num % 100000) / 1000);
    let hundred = Math.floor((num % 1000) / 100);
    let rem = num % 100;
  
    if (crore > 0) {
      words += `${ones[crore]} Crore `;
    }
    if (lakh > 0) {
      words += `${ones[lakh]} Lakh `;
    }
    if (thousand > 0) {
      words += `${ones[thousand]} Thousand `;
    }
    if (hundred > 0) {
      words += `${ones[hundred]} Hundred `;
    }
    if (rem > 0) {
      if (rem < 20) {
        words += `${ones[rem]} `;
      } else {
        words += `${tens[Math.floor(rem / 10)]} `;
        if (rem % 10 > 0) {
          words += `${ones[rem % 10]} `;
        }
      }
    }
  
    return words.trim();
  };
const [selectedGroup, setSelectedGroup] = useState(null);
  const handleServiceClick = (groupId) => {
    setSelectedService(groupId);
    setSelectedGroup(groupId); // Set the selected group
    const approversForService = {};
    
    // Assuming approvers are structured in a way that allows filtering by groupId
    for (const approverId in selectedApprovers) {
      if (selectedApprovers[approverId].serviceCd === groupId) {
        approversForService[approverId] = selectedApprovers[approverId];
      }
    }
    
    setServiceApprovers(approversForService);
  };

  return (
    <div className="modal">
      <div className="modal-content">
        <span className="close" onClick={onClose}>
          &times;
        </span>
        <h2 style={{ backgroundColor: "rgb(104, 104, 202)", color: "white" }}>
          View
        </h2>

        <form className="modal-form">
          <div className="companyid-group">
            <div>
              <label>Company ID</label>
              <input
                name="serviceCdId"
                type="text"
                value={companyId}
                disabled
              />
            </div>
            <div>
              <label>Active Flag</label>
              <input
                name="activeFlag"
                type="text"
                value={activeFlag}
                disabled
              />
            </div>
            <br />
            <div style={{ color: "navy" }}>{sowName}</div>
          </div>
          <div className="accountsno-group">
            <label>Account Number</label>
            <select
              name="accountNo"
              value={selectedAccountNo}
              onChange={handleAccountChange}
            >
              <option value="">Select Account</option>
              {accounts.map((account, index) => (
                <option
                  key={`${account.trim()}-${index}`}
                  value={account.trim()}
                >
                  {account.trim()}
                </option>
              ))}
            </select>
          </div>
          <div className="limit-details">
            <div className="tables">
              <div className="group-table">
                <table>
                  <thead>
                    <tr>
                      <th></th>
                      <th>Group Service Name</th>
                      <th>Daily Limit (In Rs.)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {groups.map((group) => (
                      <tr
                        key={group.groupId}
                        onClick={() => handleServiceClick(group.groupId)}
                      >
                        <td>
                          <input
                            type="checkbox"
                            checked={
                              selectedGroups[group.groupId] !== undefined &&
                              selectedGroups[group.groupId]?.authStatus !== "N"
                            }
                            disabled
                          />
                        </td>
                        <td>
                          <b>{group.groupName}</b>{" "}
                          {selectedGroups[group.groupId]?.activeFlag === "N" ? (
                            
                            <span style={{ color: "red" }}>
                              --Deactivated Service
                            </span>
                          ) : null}
                          <br />
                          {group.groupDesc}
                        </td>
                        <td>
                          <input
                            type="text"
                            value={
                              selectedGroups[group.groupId]?.dailyLimit || ""
                            }
                            disabled
                          />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="approvers-table">
                <table>
                  <thead>
                    <tr>
                      <th></th>
                      <th>Approver ID</th>
                      <th>Approver Name</th>
                      {/* <th>Approver Role</th> */}
                      <th>Per Transaction Limit (In Rs.)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {approvers.map((approver) => (
                      <tr key={approver.approverId}>
                        <td>
                          <input
                            type="checkbox"
                            checked={
                              selectedApprovers[approver.approverId] !==
                              undefined
                            }
                            disabled
                          />
                        </td>
                        <td>{approver.approverId}</td>
                        <td>{approver.approverName}</td>
                        {/* <td></td> */}
                        <td>
                          <input
                            type="text"
                            value={
                              selectedApprovers[approver.approverId]
                                ?.perTransactionLimit || ""
                            }
                            disabled
                          />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
            <div className="btm-limit-group">
              <div className="operation-group">
                <label>Select Operation Mode: </label>
                <label>
                  <input
                    type="radio"
                    value="O"
                    checked={operationMode === "O"}
                    onChange={() => setOperationMode("O")} // Handle change if needed
                    disabled //
                  />
                  Any one of the above
                </label>
                <label>
                  <input
                    type="radio"
                    value="J"
                    checked={operationMode === "J"}
                    onChange={() => setOperationMode("J")} // Handle change if needed
                    disabled
                  />
                  All of the above
                </label>
              </div>
              <div></div>
            </div>
          </div>

          {makerDetails.makerCd && (
            <div className="maker-author-group">
              <div>Maker: {makerDetails.makerCd}</div>
              <div>
                Maker Date:
                {makerDetails.makerDt
                  ? new Date(makerDetails.makerDt).toLocaleDateString()
                  : ""}
              </div>

              {authorDetails.authorCd && (
                <div>Author: {authorDetails.authorCd}</div>
              )}
              {authorDetails.authorCd && (
                <div>
                  Author Date:
                  {authorDetails.authorDt
                    ? new Date(authorDetails.authorDt).toLocaleDateString()
                    : ""}
                </div>
              )}
            </div>
          )}
          <div className="instructions">
            Note: 1. By selecting group service name user can 'View' or 'Update'
            limit setup of multiple group services in the 'Update' & 'View' tab.
          </div>

          <div className="button-group">
            <button type="button" onClick={onClose}>
              Close
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ViewUserModal;
