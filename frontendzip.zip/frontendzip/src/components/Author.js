import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "../css/makerFormData.css";

import NewViewModal from "./ViewModal.js";

const Form = () => {
  const [data, setData] = useState([]);
  const [accounts, setAccounts] = useState([]);
  const [approvers, setApprovers] = useState([]);
  const [searchInput, setSearchInput] = useState({
    companyID: "",
    accountNo: "",
    groupName: "",
    status: "all",
  });
  const [filteredData, setFilteredData] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedUsers, setSelectedUsers] = useState([]);

  const [formData, setFormData] = useState({});
  const recordsPerPage = 10;
  const [isNewViewModalOpen, setIsNewViewModalOpen] = useState(false);

  const [selectedCompanyId, setSelectedCompanyId] = useState(null);
  const [selectedAccountNo, setSelectedAccountNo] = useState(null);
  const [selectedActiveFlag, setSelectedActiveFlag] = useState(null);
  const [selectedStatus, setSelectedStatus] = useState(null);
  const username = localStorage.getItem("username");
  const fetchData = async () => {
    try {
      const resp = await fetch("http://192.168.0.108:8081/users/all");
      if (!resp.ok) throw new Error(`HTTP error! status: ${resp.status}`);
      const result = await resp.json();
      console.log(result);
      setData(result);
      setFilteredData(result);
    } catch (err) {
      console.log("Error fetching data", err);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setSearchInput((prev) => ({ ...prev, [name]: value }));
  };

  const handleSearch = () => {
    const results = data.filter((item) => {
      const matchesCompanyID = item.serviceCdId
        .toString()
        .includes(searchInput.companyID);
      const matchesAccountNo = item.accountNo
        .toString()
        .includes(searchInput.accountNo);
      const matchesGroupName = item.groupName
        .toLowerCase()
        .includes(searchInput.groupName.toLowerCase());
      const matchesStatus =
        searchInput.status === "all" || item.authStatus === searchInput.status;

      return (
        matchesCompanyID &&
        matchesAccountNo &&
        matchesGroupName &&
        matchesStatus
      );
    });
    setFilteredData(results);
    setCurrentPage(1);
  };

  const handleClear = () => {
    setSearchInput({
      companyID: "",
      accountNo: "",
      groupName: "",
      status: "all",
    });
    setFilteredData(data);
    setCurrentPage(1);
    setSelectedUsers([]);
  };

  const indexOfLastRecord = currentPage * recordsPerPage;
  const indexOfFirstRecord = indexOfLastRecord - recordsPerPage;
  const currentRecords = filteredData.slice(
    indexOfFirstRecord,
    indexOfLastRecord
  );
  const totalPages = Math.ceil(filteredData.length / recordsPerPage);

  const handleCheckboxChange = (user) => {
    setSelectedUsers((prev) => {
      if (prev.includes(user)) {
        return prev.filter((u) => u !== user);
      } else {
        return [...prev, user];
      }
    });
  };

  const handleView = () => {
    if (selectedUsers.length === 1) {
      const selectedUser = selectedUsers[0];
      setSelectedCompanyId(selectedUser.serviceCdId);
      setSelectedAccountNo(selectedUser.accountNo);
      setSelectedActiveFlag(selectedUser.activeFlag);
      setSelectedStatus(selectedUser.authStatus);
      setIsNewViewModalOpen(true);
    } else {
      alert("Please select exactly one record to view details.");
    }
  };

  const handleAccountChange = async (companyID) => {
    try {
      const resp = await fetch(
        `http://192.168.0.108:8081/users/approver-list/${companyID}`
      );
      if (!resp.ok) throw new Error(`HTTP error! status: ${resp.status}`);
      const approverData = await resp.json();
      console.log("Fetched Approvers:", approverData);
      // Convert object to array
      const approversArray = Object.entries(approverData).map(([id, name]) => ({
        approverId: id,
        approverName: name,
      }));

      setApprovers(approversArray);
      return approversArray;
    } catch (err) {
      console.log("Error fetching approvers", err);
      return []; // Return an empty array on error
    }
  };
  const navigate = useNavigate();
  const handleExit = () => {
    navigate("/home");
  };

  const handleAuthorize = async () => {
    if (selectedUsers.length === 1) {
      if (selectedUsers[0].makerCd === username) {
        alert("Maker cannot Authorized same record");
        return;
      } else if (selectedUsers[0].authStatus === "Authorized") {
        alert(
          "Record(s) already authorized, you can't authorize or reject authorized record(s)"
        );

        return;
      }
      const selectedUser = selectedUsers[0];
      console.log("dataa send for authorize", selectedUser);

      try {
        const response = await fetch(
          `http://192.168.0.108:8081/users/authorize`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              ...selectedUser, //  full user data
              serviceCd: selectedUser.groupId,
              authorCd: username,
            }),
          }
        );

        if (!response.ok) {
          alert("Server error during authtorization");
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        if (response.ok) {
          const result = await response.toString();
          console.log("Authorization successful:", result);
          alert("Record Authorized");
          await fetchData();
          setSelectedUsers([]);
        }
      } catch (err) {
        console.error("Error authorizing user:", err);
      }
    } else {
      alert("Please select exactly one record to authorize.");
    }
  };

  const handleReject = async () => {
    if (selectedUsers.length === 1) {
      if (selectedUsers[0].authStatus === "Authorized") {
        alert(
          "Record(s) already authorized, you can't authorize or reject authorized record(s)"
        );
      } else if (selectedUsers.length === 1) {
        const selectedUser = selectedUsers[0];
        console.log("data send for delete ", selectedUser);
        try {
          const response = await fetch(
            `http://192.168.0.108:8081/users/reject`,
            {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
              },
              body: JSON.stringify({
                ...selectedUser,
              }),
            }
          );

          if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
          }

          const result = await response.toString();
          alert("Record deleted successfully");
          console.log("Rejection successful:", result);
          await fetchData();
          setSelectedUsers([]);
        } catch (err) {
          console.error("Error rejecting user:", err);
          alert("Error during delete record", err);
        }
      } else {
        alert("Please select exactly one record to reject.");
      }
    }
    else {
      alert("Please select exactly one record to reject.");
    }
  };

  return (
    <div className="form-container">
      <h3>Single Go - Limit Maintenance Master - Author</h3>
      <hr />
      <form>
        <div className="form-group">
          <label htmlFor="companyID">Company ID</label>
          <input
            name="companyID"
            id="companyID"
            type="text"
            value={searchInput.companyID}
            onChange={handleInputChange}
          />

          <label htmlFor="accountNo">Account Number</label>
          <input
            name="accountNo"
            id="accountNo"
            type="text"
            value={searchInput.accountNo}
            onChange={handleInputChange}
          />
        </div>

        <div className="form-group">
          <label htmlFor="groupName">Group Name</label>
          <input
            name="groupName"
            id="groupName"
            type="text"
            value={searchInput.groupName}
            onChange={handleInputChange}
          />

          <label htmlFor="status">Status</label>
          <select
            name="status"
            id="status"
            value={searchInput.status}
            onChange={handleInputChange}
          >
            <option value="all">All</option>
            <option value="Authorized">Authorized</option>
            <option value="Modified">Modified</option>
            <option value="New">New</option>
          </select>
        </div>
        <div className="button-group">
          <button
            type="button"
            onClick={handleSearch}
            disabled={selectedUsers.length > 0}
          >
            Search
          </button>
          <button
            type="button"
            onClick={handleClear}
            disabled={selectedUsers.length > 0}
          >
            Clear
          </button>
          <button type="button" onClick={handleView}>
            View
          </button>
          <button type="button" onClick={handleAuthorize}>
            Authorize
          </button>
          <button type="button" onClick={handleReject}>
            Reject
          </button>
          <button type="button" onClick={handleExit} Link>
            Exit
          </button>
        </div>
      </form>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th></th>
              <th>Company Id</th>
              <th>Account Number</th>
              <th>Group Name</th>
              <th>Status</th>
              <th>Active Flag</th>
            </tr>
          </thead>
          <tbody>
            {currentRecords.length > 0 ? (
              currentRecords.map((item) => (
                <tr key={`${item.id}-${item.accountNo || item.serviceCdId}`}>
                  <td>
                    <input
                      type="checkbox"
                      checked={selectedUsers.includes(item)}
                      onChange={() => handleCheckboxChange(item)}
                    />
                  </td>
                  <td>{item.serviceCdId}</td>
                  <td>{item.accountNo}</td>
                  <td>{item.groupName}</td>
                  <td>{item.authStatus}</td>
                  <td>{item.activeFlag}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="6">No results found</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="pagination">
        <button
          onClick={() =>
            setCurrentPage(currentPage > 1 ? currentPage - 1 : currentPage)
          }
          disabled={currentPage === 1}
        >
          &lt; Prev
        </button>
        <span>
          Page {currentPage} of {totalPages}
        </span>
        <button
          onClick={() =>
            setCurrentPage(
              currentPage < totalPages ? currentPage + 1 : currentPage
            )
          }
          disabled={currentPage === totalPages}
        >
          Next &gt;
        </button>
      </div>

      {isNewViewModalOpen && (
        <NewViewModal
          onClose={() => setIsNewViewModalOpen(false)}
          companyId={selectedCompanyId}
          accountNo={selectedAccountNo}
          // serviceCd={selectedGroups}
          activeFlag={selectedActiveFlag}
          status={selectedStatus}
        />
      )}
    </div>
  );
};

export default Form;
