import { useEffect, useState } from "react";
import "../css/makerFormData.css";

const NewUserModal = ({ onClose, onSave }) => {
  const [formData, setFormData] = useState({
    serviceCdId: "",
    accountNo: "",
    activeFlag: "Y",
  });
  const [operationMode, setOperationMode] = useState("O");
  const [accounts, setAccounts] = useState([]);
  const [approvers, setApprovers] = useState([]);
  const [selectedApprovers, setSelectedApprovers] = useState({});
  const [serviceCdModified, setServiceCdModified] = useState(false);
  const username=localStorage.getItem("username")
  console.log("username fetched frm localstorage ", username);
  const [groups] = useState([
    {
      groupId: "2",
      groupName: "Financial Transactions - Bulk Transaction and Group",
      groupDesc:
        "Multiple Payments To A Single Beneficiary,Transfer Funds To Registered Group,Bulk Transaction Upload",
    },
    {
      groupId: "3",
      groupName: "Financial Transactions - Onscreen",
      groupDesc:
        "Own Account Transfer,Open FD,Remitter Payment,Create New SI,Financial Transactions,Transfer Funds To Registered Beneficiary,Ad-hoc Payment",
    },
    {
      groupId: "5",
      groupName: "Salary Management",
      groupDesc:
        "Upload Salary,Group Salary Payment,Salary Payment to Employee",
    },
    {
      groupId: "7",
      groupName: "Financial Transactions - Tax",
      groupDesc: "GST Transaction Only",
    },
  ]);
  const [selectedGroups, setSelectedGroups] = useState({});
  const [roles, setRoles] = useState({});
  const [addedServices, setAddedServices] = useState([]);
  const fetchAccounts = async (companyId) => {
    console.log("comapny id to fetch accounts ", companyId);
    try {
      const resp = await fetch(
        `http://192.168.0.108:8081/users/account-list/${companyId}`
      );
      if (!resp.ok) {
        alert("Enter valid company id");
        console.log("error while accounts fetching");
        throw new Error(`HTTP error! status: ${resp.status}`);
      }
      // if (resp.status === 400) {
      //   alert("enter valid company id");
      // }
      const accountData = await resp.json();
      console.log("accounts fetched are ", accountData);
      if (accountData.length === 0) {
        alert("Enter valid company id");
        throw new Error(`HTTP error! status: ${resp.status}`);
      }

      setAccounts(accountData);
      setServiceCdModified(true);
    } catch (err) {
      console.log("Error fetching accounts", err);
    }
  };

  const fetchApprovers = async (companyId) => {
    try {
      const resp = await fetch(
        `http://192.168.0.108:8081/users/approver-list/${companyId}`
      );
      if (!resp.ok) {
        alert("no approvers found");

        throw new Error(`HTTP error! status: ${resp.status}`);
      } else {
        const approverData = await resp.json();
        console.log("approvers fetched ", approverData);
        const approversArray = Object.entries(approverData).map(
          ([id, name]) => ({
            approverId: id,
            approverName: name,
            dailyLimit: "",
          })
        );

        setApprovers(approversArray);
        return approversArray;
      } // Return the approvers for use later
    } catch (err) {
      console.log("Error fetching approvers", err);
    }
  };

  const fetchRolesByIds = async (approverIds, accountNo) => {
    console.log(
      "data to be send for fetching roles ",
      JSON.stringify({ ids: approverIds, accountNo })
    );
    try {
      const response = await fetch(
        "http://192.168.0.108:8081/users/approvers-roles",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ ids: approverIds, accountNo }),
        }
      );

      if (!response.ok)
        throw new Error(`HTTP error! status: ${response.status}`);
      const data = await response.json();
      return data; // Expecting response to be in format: { "id": "role", ... }
    } catch (error) {
      console.error("Failed to fetch roles:", error);
      return {};
    }
  };

  useEffect(() => {
    // if (formData.serviceCdId) {
    //   fetchAccounts(formData.serviceCdId);
    // }
    //  else {
    setAccounts([]);
    setApprovers([]);
    setRoles({});
    //}
  }, [formData.serviceCdId]);

  useEffect(() => {
    const fetchApproversAndRoles = async () => {
      if (formData.accountNo && formData.serviceCdId) {
        const approversArray = await fetchApprovers(formData.serviceCdId);
        if (approversArray > 0) {
          const approverIds = approversArray.map(
            (approver) => approver.approverId
          );
          const fetchedRoles = await fetchRolesByIds(
            approverIds,
            formData.accountNo
          );
          setRoles(fetchedRoles);
        }
      }
    };

    fetchApproversAndRoles();
  }, [formData.accountNo, formData.serviceCdId]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleApproverChange = (approverId, value) => {
    setSelectedApprovers((prev) => ({
      ...prev,
      [approverId]: value,
    }));
  };

  const handleGroupChange = (groupId, value) => {
    setSelectedGroups((prev) => ({
      ...prev,
      [groupId]: value,
    }));
  };

  const handleGroupCheckboxChange = (groupId) => {
    setSelectedGroups((prevSelectedGroups) => {
      const newSelectedGroups = { ...prevSelectedGroups };

      // If the group is already selected, remove it, otherwise add it
      if (groupId in newSelectedGroups) {
        delete newSelectedGroups[groupId]; // Unselect the group
      } else {
        newSelectedGroups[groupId] = ""; // Select the group
      }

      return newSelectedGroups;
    });
  };

  const handleCheckboxChange = (approverId) => {
    setSelectedApprovers((prevSelectedApprovers) => {
      const newSelectedApprovers = { ...prevSelectedApprovers };

      // If the approver is already selected, remove it; otherwise, add it
      if (approverId in newSelectedApprovers) {
        delete newSelectedApprovers[approverId]; // Unselect the approver
      } else {
        newSelectedApprovers[approverId] = ""; // Select the approver
      }

      return newSelectedApprovers;
    });
  };
  const handleBlur = () => {
    if (formData.serviceCdId) {
      fetchAccounts(formData.serviceCdId);
    }
  };
  const handleRadioChange = (e) => {
    setOperationMode(e.target.value); // Update operation mode based on radio selection
  };

  // const handleSubmit = (e) => {
  //   e.preventDefault();

  //   // Check if at least one group is selected
  //   if (Object.keys(selectedGroups).length === 0) {
  //     alert("Please select at least one group.");
  //     return;
  //   }

  //   // Check if at least one approver is selected
  //   if (Object.keys(selectedApprovers).length === 0) {
  //     alert("Please select at least one approver.");
  //     return;
  //   }

  //   // Check if daily limits are provided for selected groups
  //   for (const [groupId, limit] of Object.entries(selectedGroups)) {
  //     if (limit === "") {
  //       alert(`Please enter a daily limit for the selected group: ${groupId}`);
  //       return;
  //     }
  //     if (isNaN(limit) || parseFloat(limit) <= 0) {
  //       alert(
  //         `Please enter a valid daily limit amount for the selected group: ${groupId}`
  //       );
  //       return;
  //     }
  //   }
  //   for (const [approverId, limit] of Object.entries(selectedApprovers)) {
  //     if (limit === "") {
  //       alert(
  //         `Please enter a per transaction limit amount for the selected approver: ${approverId}`
  //       );
  //       return;
  //     }
  //     if (isNaN(limit) || parseFloat(limit) <= 0) {
  //       alert(
  //         `Please enter a valid per transaction limit for the selected approver: ${approverId}`
  //       );
  //       return;
  //     }
  //   }

  //   // Check if group daily limit is greater than each approver's daily limit
  //   const selectedGroup = Object.entries(selectedGroups).find(
  //     ([_, limit]) => limit
  //   );
  //   const groupDailyLimit = selectedGroup ? parseFloat(selectedGroup[1]) : 0;

  //   for (const [approverId, limit] of Object.entries(selectedApprovers)) {
  //     if (limit !== "" && parseFloat(limit) > groupDailyLimit) {
  //       alert(
  //         `The daily limit for the group must be greater than the Per Transaction Limit for approver: ${approverId}`
  //       );
  //       return;
  //     }
  //   }

  //   const approverList = Object.entries(selectedApprovers)
  //     .filter(([_, limit]) => limit)
  //     .map(([id, limit]) => `${id}#${limit}`)
  //     .join("|");

  //   // Check if the service has already been added
  //   if (addedServices.some(service => service.serviceCdId === formData.serviceCdId)) {
  //     alert("This service has already been added.");
  //     return;
  //   }

  //   const selectedGroupEntry = Object.entries(selectedGroups).find(
  //     ([_, limit]) => limit
  //   );
  //   const groupId = selectedGroupEntry ? selectedGroupEntry[0] : ""; // Group ID
  //   const dailyLimit = selectedGroupEntry ? selectedGroupEntry[1] : ""; // Daily limit

  //   const userData = {
  //     accountNo: formData.accountNo,
  //     activeFlag: formData.activeFlag,
  //     approverList,
  //     authStatus: "New",
  //     authorCalDt: null,
  //     authorCd: null,
  //     authorDt: null,
  //     groupName: "",
  //     lastChangeId: 0,
  //     makerCalDt: new Date().toISOString().split("T")[0],
  //     makerCd: "SME500",
  //     makerDt: new Date().toISOString().split("T")[0],
  //     operationMode,
  //     serviceCd: groupId,
  //     serviceCdId: formData.serviceCdId,
  //     dailyLimit,
  //   };

  //   onSave(userData);
  //   onClose();
  // };

  // const handleAddToList = () => {
  //   // Validation: Check if a service is selected
  //   if (!formData.serviceCdId) {
  //     alert("Please select a service before adding to the list.");
  //     return;
  //   }

  //   // Check if at least one group is selected
  //   if (Object.keys(selectedGroups).length === 0) {
  //     alert("Please select at least one group.");
  //     return;
  //   }

  //   // Validate approvers
  //   const approverList = Object.entries(selectedApprovers)
  //     .filter(([_, limit]) => limit)
  //     .map(([id, limit]) => `${id}#${limit}`);

  //   if (approverList.length === 0) {
  //     alert("Please select at least one approver before adding to the list.");
  //     return;
  //   }

  //   // Create a new service object for each selected group
  //   const newServices = Object.entries(selectedGroups)
  //     .filter(([_, limit]) => limit) // Only include selected groups with limits
  //     .map(([groupId, dailyLimit]) => ({
  //       serviceCdId: formData.serviceCdId, // This can be the same for all
  //       groupId, // Correct groupId from selected groups
  //       approverList: approverList.join('|'), // Join approver list with the required format
  //       dailyLimit, // Daily limit for this group
  //     }));

  //   // Check for duplicates across all added services
  //   for (const newService of newServices) {
  //     if (addedServices.some(service =>
  //       service.serviceCdId === newService.serviceCdId &&
  //       service.groupId === newService.groupId)) {
  //       alert(`This service with group ID ${newService.groupId} has already been added.`);
  //       return;
  //     }
  //   }

  //   // Add the new services to the list
  //   setAddedServices((prev) => [...prev, ...newServices]);
  //   console.log("Added to list:", newServices);

  //   // Reset selections
  //   setSelectedGroups({});
  //   setSelectedApprovers({});
  // };

  const handleAddToList = () => {
    // Validation: Check if a service is selected
    if (!formData.serviceCdId) {
      alert("Please select a service before adding to the list.");
      return;
    }
  
    // Check if at least one group is selected
    if (Object.keys(selectedGroups).length === 0) {
      alert("Please select at least one group.");
      return;
    }
  
    // Validate approvers and limits
    const approverList = Object.entries(selectedApprovers)
      .filter(([_, limit]) => limit)
      .map(([id, limit]) => `${id}#${limit}`);
  
    if (approverList.length === 0) {
      alert("Please select at least one approver before adding to the list.");
      return;
    }
  
    // Validate daily limits and approver limits
    for (const [groupId, dailyLimit] of Object.entries(selectedGroups)) {
      // Check if dailyLimit is a valid number
      if (isNaN(dailyLimit) || dailyLimit === null || dailyLimit <= 0) {
        alert(`Daily limit for group ${groupId} must be a valid number.`);
        return;
      }
  
      // Validate that all approver limits are greater than or equal to the daily limit
      const approverLimits = Object.entries(selectedApprovers).filter(([_, limit]) => limit);
      const isValidLimits = approverLimits.every(([_, limit]) => {
        const parsedLimit = parseFloat(limit);
        return !isNaN(parsedLimit) &&  dailyLimit >= parsedLimit;
      });
  
      if (!isValidLimits) {
        alert(`All selected group limits must be greater than or equal to the per transaction limit of ${dailyLimit} for group ${groupId}.`);
        return;
      }
    }
  
    // Iterate through selected groups and create separate entries
    const newServices = Object.entries(selectedGroups).map(
      ([groupId, dailyLimit]) => {
        return {
          accountNo: formData.accountNo,
          activeFlag: formData.activeFlag,
          serviceCdId: formData.serviceCdId,
          serviceCd: groupId, // Each group ID
          approverList: approverList.join("|"), // Join approver list with the required format
          dailyLimit,
          activeFlag: formData.activeFlag,
          operationMode, // Daily limit for the current group
          makerCd: username,
        };
      }
    );
  
    // Check for duplicates
    const duplicates = newServices.some((newService) =>
      addedServices.some(
        (service) =>
          service.serviceCdId === newService.serviceCdId &&
          service.serviceCd === newService.serviceCd
      )
    );
  
    if (duplicates) {
      alert(
        "One or more of these services with the selected groups has already been added."
      );
      return;
    }
  
    // Add the new services to the list
    setAddedServices((prev) => [...prev, ...newServices]);
    console.log("Added to list:", newServices);
  
    // Reset selections
    setSelectedGroups({});
    setSelectedApprovers({});
  };
  
  //submit neww
  const handleSubmit = (e) => {
    e.preventDefault();
  
    // Check if addedServices is empty
    if (addedServices.length === 0) {
      alert("Please add services to list before submitting.");
      return;
    }
  
    console.log("Submitting addedServices list:", addedServices); // Log the list before submitting
  
    // Only send the list of added services
    onSave(addedServices);
    onClose();
  };
  
  
  const handleCopyLimit = () => {
    // Find the limit of the first selected approver
    const selectedApproverIds = Object.keys(selectedApprovers);
    if (selectedApproverIds.length === 0) {
      alert("Please select at least one approver to copy the limit.");
      return;
    }
  
    // Get the first selected approver's ID
    const firstApproverId = selectedApproverIds[0];
    const limitToCopy = selectedApprovers[firstApproverId];
  
    // Update all selected approvers with the copied limit
    const updatedApprovers = {};
    for (const approverId of selectedApproverIds) {
      updatedApprovers[approverId] = limitToCopy;
    }
    setSelectedApprovers(updatedApprovers);
  };
//number to word

const numberToWords = (num) => {
  const ones = [
    '', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
    'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen',
    'Seventeen', 'Eighteen', 'Nineteen'
  ];

  const tens = [
    '', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'
  ];

  const aboveHundred = [
    '', 'Hundred', 'Thousand', 'Lakh', 'Crore'
  ];

  if (num === 0) return 'Zero';

  let words = '';
  let crore = Math.floor(num / 10000000);
  let lakh = Math.floor((num % 10000000) / 100000);
  let thousand = Math.floor((num % 100000) / 1000);
  let hundred = Math.floor((num % 1000) / 100);
  let rem = num % 100;

  if (crore > 0) {
    words += `${ones[crore]} Crore `;
  }
  if (lakh > 0) {
    words += `${ones[lakh]} Lakh `;
  }
  if (thousand > 0) {
    words += `${ones[thousand]} Thousand `;
  }
  if (hundred > 0) {
    words += `${ones[hundred]} Hundred `;
  }
  if (rem > 0) {
    if (rem < 20) {
      words += `${ones[rem]} `;
    } else {
      words += `${tens[Math.floor(rem / 10)]} `;
      if (rem % 10 > 0) {
        words += `${ones[rem % 10]} `;
      }
    }
  }

  return words.trim();
};

  return (
    <div className="modal">
      <div className="modal-content">
        <span className="close" onClick={onClose}>
          &times; 
        </span>
        <h2 style={{ backgroundColor: "rgb(104, 104, 202)", color: "white" }}>New</h2>
        <form className="modal-form" onSubmit={handleSubmit}>
          <div className="companyid-group">
            <div>
              <label>
                Company ID<span className="mandatory">*</span>
              </label>
              <input
                name="serviceCdId"
                type="text"
                value={formData.serviceCdId}
                onChange={handleChange}
                onBlur={handleBlur}
                disabled={serviceCdModified}
                required
              />
            </div>
            <div>
              <label>Active Flag</label>
              <input
                name="activeFlag"
                type="text"
                value={formData.activeFlag}
                onChange={handleChange}
                disabled
              />
            </div>
          </div>
          <div className="accountsno-group">
            <label>Account Number</label>
            <select
              name="accountNo"
              value={formData.accountNo}
              onChange={handleChange}
              required
            >
              <option value="">Select Account</option>
              {accounts.map((account, index) => (
                <option
                  key={`${account.trim()}-${index}`}
                  value={account.trim()}
                >
                  {account.trim()}
                </option>
              ))}
            </select>
          </div>
          <div className="limit-details">
            {accounts.length > 0 ? (
              <div>
                <div className="tables">
                  <div className="group-table">
                  <table>
  <thead>
    <tr>
      <th></th>
      <th>Group Service Name</th>
      <th>Daily Limit (In Rs.)</th>
      <th>Daily Limit (In Words)</th>
    </tr>
  </thead>
  <tbody>
    {groups.map((group) => {
      const dailyLimit = selectedGroups[group.groupId] || ""; // Get the daily limit for this group
      const amountInWords = dailyLimit ? numberToWords(Number(dailyLimit)) : ""; // Convert to words if there's a valid amount

      return (
        <tr key={group.groupId}>
          <td>
            <input
              type="checkbox"
              checked={
                selectedGroups[group.groupId] !== undefined ||
                addedServices.some(
                  (service) => service.serviceCdId === group.groupId
                )
              }
              onChange={() => handleGroupCheckboxChange(group.groupId)}
              disabled={addedServices.some(
                (service) => service.serviceCdId === group.groupId
              )}
            />
          </td>
          <td>
            <b>{group.groupName}</b>
            <br />
            {group.groupDesc}
          </td>
          <td>
            <input
              type="text"
              value={dailyLimit}
              onChange={(e) =>
                handleGroupChange(group.groupId, e.target.value)
              }
              placeholder="Daily limit"
              disabled={
                selectedGroups[group.groupId] === undefined ||
                addedServices.some(
                  (service) => service.serviceCdId === group.groupId
                )
              }
            />
          </td>
          <td><input value={amountInWords}/></td> {/* Display amount in words here */}
        </tr>
      );
    })}
  </tbody>
</table>

                  </div>

                  <div className="approvers-table">
                    <table>
                      <thead>
                        <tr>
                          <th></th>
                          <th>Approver ID</th>
                          <th>Approver Name</th>
                          <th>Role</th>
                          <th>Per Transaction Limit (In Rs.)</th>
                        </tr>
                      </thead>
                      <tbody>
                        {approvers.length > 0 &&
                          approvers.map((approver) => {
                            const isDisabled =
                              approver.approverId === formData.serviceCdId;
                            return (
                              <tr key={approver.approverId}>
                                <td>
                                  <input
                                    type="checkbox"
                                    checked={
                                      selectedApprovers[approver.approverId] !==
                                      undefined
                                    }
                                    onChange={() =>
                                      handleCheckboxChange(approver.approverId)
                                    }
                                    disabled={
                                      isDisabled ||
                                      roles[approver.approverId] === "sow"
                                    }
                                  />
                                </td>
                                <td>{approver.approverId}</td>
                                <td>{approver.approverName}</td>
                                <td>{roles[approver.approverId] || ""}</td>
                                <td>
                                  <input
                                    type="text"
                                    value={
                                      selectedApprovers[approver.approverId] ||
                                      ""
                                    }
                                    onChange={(e) =>
                                      handleApproverChange(
                                        approver.approverId,
                                        e.target.value
                                      )
                                    }
                                    placeholder="Enter limit"
                                    disabled={
                                      isDisabled ||
                                      selectedApprovers[approver.approverId] ===
                                        undefined ||
                                      roles[approver.approverId] === "sow"
                                    }
                                  />
                                </td>
                              </tr>
                            );
                          })}
                      </tbody>
                    </table>
                  </div>
                </div>
                <div className="btm-limit-group">
                  <div className="operation-group">
                    <label>Select Operation Mode: </label>
                    <label>
                      <input
                        type="radio"
                        value="O"
                        checked={operationMode === "O"}
                        onChange={handleRadioChange}
                      />
                      Any one of the above
                    </label>
                    <label>
                      <input
                        type="radio"
                        value="J"
                        checked={operationMode === "J"}
                        onChange={handleRadioChange}
                      />
                      All of the above
                    </label>
                  </div>
                  <div className="options-group">
                    <button type="button" onClick={handleAddToList}>
                      Add to list
                    </button>
                     <button type="button" onClick={handleCopyLimit}>
    Copy Transaction Limit
  </button>
                  </div>
                </div>
              </div>
            ) : (
              "No account selected"
            )}
          </div>

          <div className="instructions">
            Note: 1. "Daily limit should not be less than Per-transaction
            limit"(This check is available when we are maintaining limit of all
            services in a single click on "Add to list" button).
          </div>

          <div className="button-group">
            <button type="submit">Add</button>
            <button type="button" onClick={onClose}>
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default NewUserModal;
