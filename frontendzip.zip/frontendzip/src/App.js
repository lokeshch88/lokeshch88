import "./App.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import MakerDashboard from "./components/MakerForm";
import AuthorForm from "./components/Author";
import Login from "./components/Login";
import Home from "./components/Home";

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
        <Route path="/" element={<Login/>} />
          <Route path="/home" element={<Home/>} />
          <Route path="/maker-dashboard" element={<MakerDashboard />} />
          <Route path="/author-dashboard" element={<AuthorForm />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
